# Publier le site sur GitHub Pages

Adresse provisoire utilisée partout dans les fichiers : `https://VOTRE-NOM.github.io/purification-biomolecules/`
Vous allez la remplacer par votre vraie adresse (étape 3).

## 1. Créer le dépôt
1. Créez un compte sur github.com puis un nouveau dépôt **public** (par exemple `purification-biomolecules`).
2. Ajoutez tout le contenu de ce dossier (glissez les fichiers dans la page du dépôt, « Add file » puis « Upload files »). Le fichier `index.html` doit être à la racine.

## 2. Activer GitHub Pages
Dépôt : Settings, Pages, Source : « Deploy from a branch », branche `main`, dossier `/ (root)`, Save.
Après une à deux minutes, l'adresse du site s'affiche : `https://VOTRE-PSEUDO.github.io/NOM-DU-DEPOT/`.

## 3. Mettre la vraie adresse partout
Avec Python : `python tools/set-url.py https://VOTRE-PSEUDO.github.io/NOM-DU-DEPOT/`
Sans Python : dans un éditeur (Visual Studio Code, « Remplacer dans les fichiers »), remplacez `https://VOTRE-NOM.github.io/purification-biomolecules/` par votre adresse dans `index.html`, `sitemap.xml`, `robots.txt` et `js/config.js`.
Envoyez ensuite les fichiers modifiés sur GitHub.

## 4. Vérifier l'aperçu sur les réseaux (après publication)
- Facebook : developers.facebook.com/tools/debug (collez l'adresse, « Scrape again »)
- LinkedIn : linkedin.com/post-inspector
- X (Twitter) : publiez un brouillon de message avec le lien pour voir la carte
- Pinterest : developers.pinterest.com/tools/url-debugger
- Google : search.google.com/search-console (ajoutez le site, envoyez `sitemap.xml`)
Les aperçus utilisent l'image `assets/social/og-image.png` (1200 x 630).

## 5. Contenu du dépôt
- `index.html`, `css/`, `js/`, `assets/` : le site
- `site.webmanifest`, `browserconfig.xml`, `favicon.ico`, `assets/icons/` : icônes et application
- `robots.txt`, `sitemap.xml` : référencement
- `404.html` : page d'erreur ; `.nojekyll` : évite que GitHub transforme le site
- `.gitignore`, `LICENSE.txt` : fichiers du dépôt
- `tools/` : outils modifiables (code QR, résumé d'une page, affiche, changement d'adresse)

## 6. Nom de domaine personnalisé (facultatif)
Settings, Pages, Custom domain. Mettez ensuite la nouvelle adresse avec `tools/set-url.py`.
