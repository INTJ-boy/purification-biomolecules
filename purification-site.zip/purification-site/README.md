# Procédés de purification de biomolécules : interactive site / site interactif

**Publier le site** : lisez `GUIDE-PUBLICATION.md`. **Mettre à jour les documents** : `GUIDE-MISE-A-JOUR-DOCUMENTS.md`. **Partager** : `PARTAGE-RESEAUX.md`.


Open `index.html` in a browser. **The site works offline**: no external font or library is loaded (the 3D helix is drawn on a canvas, fonts are the device fonts).

## Where to change what / Où modifier quoi
| I want to change | File | Where |
|---|---|---|
| Any text (French or English), titles, module, year, examiner | `js/content.js` | grouped by chapter, comments `/* ---- ... ---- */` |
| References list | `js/content.js` | `REFS` at the bottom |
| Name shown as presenter (add names for a pyramid) | `js/config.js` | `MEMBERS` |
| Documents offered for download (Word, PDF, PowerPoint) | `assets/downloads/` and `js/downloads-data.js` | `DL_DATA` |
| Colors and fonts | `css/theme.css` | `:root{...}` |
| Layout, spacing, components | `css/style.css` | 8 numbered sections |
| Animated drawings of the 6 techniques | `js/scenes.js` | `scene(i)` |
| Laboratory models and sliders | `js/labs.js` | `LAB[0..9]` (7 techniques incl. electrophoresis, then monolith, two-phase system, continuous chromatography) |
| Process challenge game (products, techniques, costs, budget) | `js/builder.js` | `PB_STARTS`, `PB_OPS`, `PB_MOD`, `PB_BUDGET` |
| Journey of the molecule animation | `js/journey.js` | `JR_*` |
| Acarbose structure and mechanism animation | `js/acarbose.js` | `AC_P` (bite speed) |
| Advanced techniques cards (4.3), impurities, QC table, product sheet | `js/advanced.js` + texts in `js/content.js` (`adv`, `imp`, `qcc`, `pf`) | `advBuild()` |
| Methods edit timing and sound (3 loops) | `js/edit.js` | `T0`, `BP`, `NB`, `LOOPS`, `sched()` (16-beat seamless loops) |
| Types of each technique (chips and atlas) | `js/content.js` | `types` (one list per technique) |\n| Presenter notes | `js/content.js` | `notes` |
| Search palette (Ctrl+K or / key) | `js/ui.js` | `cmdItems()` |
| Website address of the QR code (GitHub link placeholder) | `js/config.js` | `SITE_URL` |
| History timeline, quality by design, antibody example, QR card | `js/extra.js` + texts in `js/content.js` | `hist`, `qbd`, `s3`, `e2cmp`, `qr_*` |
| Page structure, section order | `index.html` | comments mark each chapter |
| 3D helix colors | `js/helix.js` | `COL_A`, `COL_B` |
| Images | `assets/` | logos, banner, CORECT box photo |

## Placeholders to fill
- `[À ADAPTER]` / `[TO ADAPT]` in `js/content.js`: process steps of the Acarbose example (Biopharm's own process is not public).

## Notes
- Script order in `index.html` matters (core, content, config, audio-data, scenes, labs, builder, journey, acarbose, qr, advanced, extra, edit, ui, main, helix).
- `js/audio-data.js` holds the sound as text so the site works when opened from a folder. `assets/sound-of-the-video.mp3` is the same sound for reference.
- The published single-file version is built from these files.
