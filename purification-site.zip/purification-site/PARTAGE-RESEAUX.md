# Partager le site sur les réseaux

Adresse (à remplacer) : https://VOTRE-NOM.github.io/purification-biomolecules/

## Quelle image pour quel réseau
| Réseau | Image | Taille |
|---|---|---|
| Facebook, LinkedIn, WhatsApp, Telegram, X, Slack | `assets/social/og-image.png` (prise automatiquement depuis l'adresse) | 1200 x 630 |
| Instagram (publication) | `assets/social/social-square.png` | 1080 x 1080 |
| Pinterest | `assets/social/pinterest.png` | 1000 x 1500 |
Instagram n'affiche pas de lien cliquable dans une légende : mettez l'adresse dans la bio.

## Textes prêts à copier
**Facebook / LinkedIn**
Je partage mon exposé interactif « Procédés de purification de biomolécules » : sept techniques, un laboratoire virtuel et l'étude de l'acarbose CORECT® (Biopharm). https://VOTRE-NOM.github.io/purification-biomolecules/
#biotechnologie #purification #chromatographie #acarbose #USTHB

**X (Twitter)**
Exposé interactif sur la purification des biomolécules : techniques, laboratoire virtuel et l'exemple de l'acarbose CORECT®. https://VOTRE-NOM.github.io/purification-biomolecules/ #biotech #purification

**Instagram** (lien dans la bio)
Purifier une biomolécule : comment obtenir une molécule pure, stable et active à l'échelle industrielle ? Découvrez mon exposé interactif, lien dans la bio. #biotechnologie #science #purification #chromatographie #acarbose

**Pinterest** (titre) Procédés de purification de biomolécules : exposé interactif
(description) Sept techniques de purification, laboratoire virtuel et étude de l'acarbose CORECT® (Biopharm). Lien du site en destination.
