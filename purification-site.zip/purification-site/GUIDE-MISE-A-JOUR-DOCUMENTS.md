# Mettre à jour les documents (Word, PowerPoint, PDF, affiche)

Les quatre documents du site sont dans `assets/downloads/`. Pour en changer un : remplacez le fichier par un nouveau **du même nom**, puis (facultatif) remplacez l'image d'aperçu du même nom dans `assets/previews/` (exportez la première page en JPG).

## Le code QR (le seul élément qui dépend de l'adresse du site)
1. Ouvrez `tools/qr-generator.html` dans Chrome, collez l'adresse du site, cliquez « Télécharger l'image (PNG) ».
2. **Word** (`Compte_rendu_purification_biomolecules.docx`) : annexe A, clic droit sur le code QR, « Modifier l'image » (Change Picture), choisissez le PNG. Fichier, Enregistrer sous, PDF si vous voulez aussi la version PDF.
3. **PowerPoint** (`Resume_PowerPoint.pptx`) : diapositive 8, clic droit sur le code QR, « Modifier l'image », puis changez la phrase « Lien provisoire » dans la zone de texte.
4. **Résumé d'une page** et **Affiche** : changez `SITE_URL` dans `js/config.js`, ouvrez `tools/resume-1-page.html` ou `tools/poster.html` dans Chrome, Ctrl+P, destination « Enregistrer au format PDF », marges « Aucune », cochez « Graphiques d'arrière-plan », échelle 100 %. Le code QR est régénéré automatiquement. Enregistrez sous `Resume_1_page.pdf` ou `Affiche_poster_A3.pdf` dans `assets/downloads/`. Pour l'affiche, choisissez le format A3.

## Changer un texte, un nom ou le nom du module
- Textes du site (français et anglais) : `js/content.js`. Nom présenté : `js/config.js`.
- Résumé et affiche : modifiez directement le texte dans `tools/resume-1-page.html` et `tools/poster.html`.
- Word et PowerPoint : modifiez-les dans Word et PowerPoint. Dans Word, le sommaire est écrit à la main : si vous ajoutez du texte avant une section, vérifiez les numéros de page.

## Rappel
Après chaque changement de fichier sur GitHub, attendez une à deux minutes et rechargez la page (Ctrl+F5).
